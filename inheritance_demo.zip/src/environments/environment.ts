export const environment = {
    name: 'dev'
};
