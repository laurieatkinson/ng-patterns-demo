export const environment = {
    name: 'deploy'
};
