import { Component, ViewEncapsulation } from '@angular/core';

@Component({
    selector: 'la-top-nav',
    templateUrl: './top-nav.component.html',
    styleUrls: ['./top-nav.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class TopNavComponent {
}
