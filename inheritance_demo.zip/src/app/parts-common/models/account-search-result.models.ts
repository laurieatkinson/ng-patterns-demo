export interface IAccountSearchResult {
    accountCode: string;
    accountName: string;
    accountType: string;
    accountStatus: number;
    accountStatusDisplay: string;
}
