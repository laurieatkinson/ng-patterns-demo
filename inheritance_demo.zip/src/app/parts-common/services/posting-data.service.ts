import { Injectable } from '@angular/core';
import { INewTransaction, IPlanPostingObject, ITransactionIdentifier } from '../models/postings.models';
import { PartsCommonDataService } from './parts-common-data.service';

@Injectable()
export class PostingDataService extends PartsCommonDataService {

    getPostingObject() {
        const endpoint = `${this.apiServer.rules}planinquiry/plans/${this.userSessionService.accountCode.toUpperCase()}/postingobject`;

        const promise = new Promise<IPlanPostingObject>((resolve, reject) => {
            this.get<IPlanPostingObject>(endpoint).then((postingObject) => {
                resolve(postingObject);
            }).catch((error) => {
                reject(error);
            });
    });
    return promise;

    }

    createPosting(posting: INewTransaction): Promise<ITransactionIdentifier> {
        const endpoint = `${this.apiServer.transaction}postings`;
        return <Promise<ITransactionIdentifier>>(this.post<ITransactionIdentifier>(endpoint, posting));
    }

    commitPosting(postId: number, description: string): Promise<string> {
        const endpoint = `${this.apiServer.transaction}postings/commit`;
        return <Promise<string>>(this.post<ITransactionIdentifier>(endpoint,
            {
                postId: postId,
                description: description
            }));
    }

    rollbackPosting(postId: number): Promise<string> {
        const endpoint = `${this.apiServer.transaction}postings/${postId}/rollback`;
        return <Promise<string>>(this.post<ITransactionIdentifier>(endpoint, null));
    }
}
