import { Injectable } from '@angular/core';
import { IAccountSearchResult } from '../models/account-search-result.models';
import { PartsCommonDataService } from './parts-common-data.service';

@Injectable()
export class SearchDataService extends PartsCommonDataService {

    getAccountSearchResults() {
        const endpoint = `${this.apiServer.rules}planinquiry/plans/`;
        return this.get<Array<IAccountSearchResult>>(endpoint);
    }
}
