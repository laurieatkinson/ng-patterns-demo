export enum ConfirmChoice {
    save,
    discard,
    cancel
}
