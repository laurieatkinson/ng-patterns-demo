import { Injectable } from '@angular/core';
import { MetadataDataService } from './metadata-data.service';
import { IPartsListChoice } from '../models/form-controls.models';

@Injectable()
export class MetadataService {

    private dropdownLists: Array<{ name: string, items: Array<IPartsListChoice> }> = [];

    constructor(private metadataDataService: MetadataDataService) {
    }

    getLookupList(name: string) {
        const promise = new Promise<IPartsListChoice[]>((resolve, reject) => {
            const index = this.dropdownLists.findIndex(item => item.name === name);
            if (index > -1) {
                resolve(this.dropdownLists[index].items);
            } else {
                this.metadataDataService.getLookupList(name)
                    .then(list => {
                        const formattedList = Object.keys(list).map(key => {
                            return { value: key, label: list[key] };
                        });
                        this.dropdownLists.push({ name: name, items: formattedList });
                        resolve(formattedList);
                    }).catch((e) => {
                        reject(e);
                    });
            }
        });
        return promise;
    }

    getTimePeriodList(type: 'A' | 'B' | 'C' | 'D' | 'E' = 'A') {
        const promise = new Promise<IPartsListChoice[]>((resolve, reject) => {
            const index = this.dropdownLists.findIndex(item => item.name === 'TimePeriods');
            if (index > -1) {
                resolve(this.dropdownLists[index].items);
            } else {
                this.metadataDataService.getTimePeriodList(type)
                    .then(list => {
                        list.sort((item1, item2) => {
                            return item1.uniqueId < item2.uniqueId ? -1 : item1.uniqueId > item2.uniqueId ? 1 : 0;
                        });
                        const formattedList = list.map(timePeriod => {
                            return { value: timePeriod.freqPerYear, label: timePeriod.frequency };
                        });
                        this.dropdownLists.push({ name: `TimePeriods_${type}`, items: formattedList });
                        resolve(formattedList);
                    }).catch((e) => {
                        reject(e);
                    });
            }
        });
        return promise;
    }
}
