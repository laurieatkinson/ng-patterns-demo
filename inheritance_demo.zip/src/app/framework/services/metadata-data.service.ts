import { Injectable } from '@angular/core';
import { DataService } from './data.service';
import { ILookupList, ITimePeriod } from '../models/metadata.models';

// AJAX calls related to metadata
@Injectable()
export class MetadataDataService extends DataService {

    getTimePeriodList(type: 'A' | 'B' | 'C' | 'D' | 'E' = 'A'): Promise<Array<ITimePeriod>> {
        let endpoint = `${this.apiServer.metadata}metadata/timeperiods`;
        if (type) {
            endpoint = this.appendParameter(endpoint, 'timePeriodType', type);
        }
        return this.get<Array<ITimePeriod>>(endpoint);
    }

    getLookupList(name: string): Promise<Array<ILookupList>> {
        const endpoint = `${this.apiServer.metadata}metadata/lookuplists/${name}`;
        return this.get<Array<ILookupList>>(endpoint);
    }
}
