import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuardService } from '../framework/services/auth-guard.service';
import { CanDeactivateGuardService } from '../framework/services/can-deactivate-guard.service';
import { ChildComponent1Resolver } from './plans/child-component1/child-component1-resolver.service';
import { SearchResultsComponent } from './search/search-results/search-results.component';
import { SearchResultsResolver } from './search/search-results/search-results-resolver.service';
import { NavigationErrorComponent } from './plans/shared/components/navigation-error/navigation-error.component';
import { ChildComponent1Component } from './plans/child-component1/child-component1.component';
import { ChildComponent2Component } from './plans/child-component2/child-component2.component';
import { ChildComponent2Resolver } from './plans/child-component2/child-component2-resolver.service';
import { ChildComponent3Resolver } from './plans/child-component3/child-component3-resolver.service';

const routes: Routes = [
    {
        path: 'inquiry',
        canActivate: [AuthGuardService],
        children: [
            {
                path: '',
                data: { actionCode: 'PLANINQ_VIEW_ONLY' },
                children: [
                    {
                        path: 'plans/searchresults',
                        component: SearchResultsComponent,
                        resolve: { searchResults: SearchResultsResolver },
                        canDeactivate: [CanDeactivateGuardService]
                    },
                    {
                        path: 'plans/:code/navigation-error/:id',
                        component: NavigationErrorComponent,
                        canDeactivate: [CanDeactivateGuardService]
                    },
                    {
                        path: 'plans/:code',
                        component: ChildComponent1Component,
                        resolve: { plan: ChildComponent1Resolver },
                        canDeactivate: [CanDeactivateGuardService]
                    },
                    {
                        path: 'plans/:code/child2',
                        component: ChildComponent2Component,
                        resolve: { child2: ChildComponent2Resolver },
                        canDeactivate: [CanDeactivateGuardService]
                    },
                    {
                        path: 'plans/:code/child3',
                        component: ChildComponent2Component,
                        resolve: { child3: ChildComponent3Resolver },
                        canDeactivate: [CanDeactivateGuardService]
                    }
                ]
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class InquiryRoutingModule { }
