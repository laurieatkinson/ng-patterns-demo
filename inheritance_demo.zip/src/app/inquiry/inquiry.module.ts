import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { FrameworkModule } from '../framework/framework.module';
import { PartsCommonModule } from '../parts-common/parts-common.module';
import { InquiryRoutingModule } from './inquiry-routing.module';
import { PlanUpdateService } from './plans/shared/services/plan-update.service';
import { AccountDataService } from './plans/shared/services/account-data.service';
import { AccountHeaderService } from './plans/shared/directives/account-header/account-header.service';
import { PlanMenuService } from './plans/shared/services/plan-menu.service';
import { PartsPostingComponent } from './plans/shared/components/parts-posting-component';
import { AccountHeaderComponent } from './plans/shared/directives/account-header/account-header.component';
import { ChildComponent1Resolver } from './plans/child-component1/child-component1-resolver.service';
import { SearchResultsComponent } from './search/search-results/search-results.component';
import { SearchResultsResolver } from './search/search-results/search-results-resolver.service';
import { Child3DataService } from './plans/shared/services/child3-data.service';
import { PlanHeaderMenuComponent } from './plans/shared/directives/plan-header-menu/plan-header-menu.component';
import { Child2DataService } from './plans/shared/services/child2-data.service';
import { NavigationErrorComponent } from './plans/shared/components/navigation-error/navigation-error.component';
import { ChildComponent1Component } from './plans/child-component1/child-component1.component';
import { Child1DataService } from './plans/shared/services/child1-data.service';
import { ChildComponent2Component } from './plans/child-component2/child-component2.component';
import { ChildComponent2Resolver } from './plans/child-component2/child-component2-resolver.service';
import { ChildComponent3Component } from './plans/child-component3/child-component3.component';
import { ChildComponent3Resolver } from './plans/child-component3/child-component3-resolver.service';

@NgModule({
    imports: [
        CommonModule,
        HttpClientModule,
        FrameworkModule,
        PartsCommonModule,
        InquiryRoutingModule
    ],
    declarations: [
        PartsPostingComponent,
        ChildComponent1Component,
        ChildComponent2Component,
        ChildComponent3Component,
        AccountHeaderComponent,
        SearchResultsComponent,
        PlanHeaderMenuComponent,
        NavigationErrorComponent
    ],
    providers: [
        AccountDataService,
        PlanUpdateService,
        AccountHeaderService,
        ChildComponent1Resolver,
        ChildComponent2Resolver,
        ChildComponent3Resolver,
        SearchResultsResolver,
        Child1DataService,
        Child2DataService,
        Child3DataService,
        PlanMenuService
    ],
    exports: [
    ]
})
export class InquiryModule { }
