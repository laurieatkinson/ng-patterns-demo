import { ActivatedRoute, Router } from '@angular/router';
import { SearchService } from '../../../parts-common/services/search.service';
import { UserSessionService } from '../../../parts-common/services/user-session.service';
import { SearchResultsComponent } from './search-results.component';
import { Observable } from 'rxjs/Observable';
import { IAccountSearchResult } from '../../../parts-common/models/account-search-result.models';
import { TestInjector } from '../../../parts-common/testing/testing-helpers';

const searchResults = [{
    accountCode: 'ABC123',
    accountName: 'Test Account',
    accountType: ''
},
{
    accountCode: 'ABC234',
    accountName: 'Test Account2',
    accountType: ''
}
];

class MockActivatedRoute extends ActivatedRoute {
    data = Observable.of({ searchResults: searchResults });
}

class MockSearchService {
    getAccounts(): Promise<Array<IAccountSearchResult>> {
        return new Promise<Array<IAccountSearchResult>>((resolve) => {
            resolve(<Array<IAccountSearchResult>>searchResults);
        });
    }
}

describe('SearchResultsComponent', () => {
    let component: SearchResultsComponent;

    beforeAll(() => {
        TestInjector.setInjector([
            { provide: SearchService, useClass: MockSearchService }
        ]);
    });
    beforeEach(() => {
      component = new SearchResultsComponent(
        new MockActivatedRoute(),
        TestInjector.getService(UserSessionService));
      component.ngOnInit();
    });

    it('should be created', () => {
        expect(component).toBeTruthy();
    });

    it('should get all accounts by default', () => {
        expect(component.searchResultList.length).toBe(2);
    });
});
