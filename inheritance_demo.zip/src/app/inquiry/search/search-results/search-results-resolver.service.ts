import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { IAccountSearchResult } from '../../../parts-common/models/account-search-result.models';
import { PartsPostingResolver } from '../../../parts-common/services/parts-posting-resolver.service';
import { SearchService } from '../../../parts-common/services/search.service';

@Injectable()
export class SearchResultsResolver extends PartsPostingResolver
                                   implements Resolve<Array<IAccountSearchResult>> {

    constructor(private searchService: SearchService) {
        super();
    }

    resolve(route: ActivatedRouteSnapshot) {
        super.resolve(route);
        return this.searchService.getAccounts();
    }
}
