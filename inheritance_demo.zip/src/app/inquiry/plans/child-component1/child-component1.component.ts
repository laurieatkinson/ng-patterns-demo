import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PartsPostingComponent } from '../shared/components/parts-posting-component';
import { SearchService } from '../../../parts-common/services/search.service';
import { AccountHeaderService } from '../shared/directives/account-header/account-header.service';
import { IChild1Entity } from '../shared/models/child1-entity.models';
import { Child1DataService } from '../shared/services/child1-data.service';

@Component({
    selector: 'la-plan-basic-info',
    templateUrl: './child-component1.component.html',
    styleUrls: ['./child-component1.component.scss']
})
export class ChildComponent1Component extends PartsPostingComponent {

    child1: IChild1Entity;
    formControls = [
        { name: 'planAlias' },
        { name: 'name1' },
        { name: 'name2' },
        { name: 'name3' },
        { name: 'addressLine1' },
        { name: 'addressLine2' },
        { name: 'addressLine3' },
        { name: 'city' },
        { name: 'state' },
        { name: 'zip' },
        { name: 'country' },
        { name: 'planGroup' },
        { name: 'planType' },
        { name: 'planID5500' },
        { name: 'planSponsorName' },
        { name: 'planSponsorEIN' },
        { name: 'planStatus' },
        { name: 'productCode' },
        { name: 'topHeavyCode' },
        { name: 'trustCustodianRelation' },
        { name: 'industryCode' },
        { name: 'trustID' },
        { name: 'addedDate' },
        { name: 'inceptionDate' },
        { name: 'removedDate' },
        { name: 'lastAmendmentDate' },
        { name: 'repaperedDate' },
        { name: 'supressSSN' },
        { name: 'nonERISAPlan' }
    ];
    protected routeParamName = 'account';
    private originalChild1: IChild1Entity;

    constructor(protected route: ActivatedRoute,
        private searchService: SearchService,
        private accountHeaderService: AccountHeaderService,
        private planBasicInfoDataService: Child1DataService) {
        super(route);
    }

    protected get original() {
        return this.originalChild1;
    }

    protected set original(value: IChild1Entity) {
        this.originalChild1 = value;
    }

    protected get postingEntity() {
        return this.child1;
    }

    saveComplete() {
        super.saveComplete();
        this.accountHeaderService.updateAccountName(
            this.child1.name1, this.child1.name2, this.child1.name3);
    }

    commitComplete() {
        super.commitComplete();
        // When an account is updated, we need to update the cached copy of the search results
        this.searchService.accountUpdated(this.child1);
    }

    protected set postingEntity(value: IChild1Entity) {
        value.state = value.state.toUpperCase();
        this.child1 = value;
    }

    protected get dataService() {
        return this.planBasicInfoDataService;
    }
}
