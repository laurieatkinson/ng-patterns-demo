import { TestBed, inject } from '@angular/core/testing';
import { Observable } from 'rxjs/Observable';
import { UserSessionService } from '../../../../../parts-common/services/user-session.service';
import { IAccount } from '../../models/account.models';
import { AccountDataService } from '../../services/account-data.service';
import { AccountHeaderService } from './account-header.service';
import { UtilitiesService } from '../../../../../framework/services/utilities.service';

describe('AccountHeaderService', () => {

    const account = {
        name1: 'Test Account'
    };
    let service: AccountHeaderService;

    class MockAccountDataService {
        currentAccount = {
            accountCode: 'ABC123',
            name1: 'Test Plan',
            name2: 'Name 2',
            name3: 'Name 3'
        };
        accountChanged = Observable.of();
        userSelectedAnotherAccount(): boolean {
            return false;
        }
        getAccount(): Promise<IAccount> {
            return new Promise<IAccount>((resolve) => {
                resolve(<IAccount>account);
            });
        }
        userUpdatedPlanName(name1: string, name2: string, name3: string) {
        }
    }

    beforeEach(() => {
        TestBed.configureTestingModule({
            providers: [
                AccountHeaderService,
                UserSessionService,
                UtilitiesService,
                {
                    provide: AccountDataService,
                    useClass: MockAccountDataService
                }
            ]
        });
    });

    beforeEach(inject([AccountHeaderService], (s: AccountHeaderService) => {
        service = s;
    }));

    it('should create the service', () => {
        expect(service).toBeTruthy();
    });

    it('can initialize', () => {
        service.initialize();
    });

    it('can initialize with same account selected', () => {
        service.initialize().then((currentAccount) => {
            expect(currentAccount.name1).toBe(account.name1);
        }).catch(error => {
            expect(error).toBeNull();
        });
    });

    it('can update account name', () => {
        service.initialize().then((currentAccount) => {
            service.updateAccountName('new name1', 'new name2', 'new name3');
            expect(service.accountName1).toBe('new name1');
        }).catch(error => {
            expect(error).toBeNull();
        });
    });

    it('can initialize with another account selected',
        inject([AccountDataService], (accountDataService: AccountDataService) => {
        spyOn(accountDataService, 'userSelectedAnotherAccount')
            .and.returnValue(true);
        spyOn(service, 'accountChanged');
        service.initialize().then((currentAccount) => {
            accountDataService.accountChanged.subscribe(() => {
                expect(service.accountChanged).toHaveBeenCalled();
            });
        }).catch(error => {
            expect(error).toBeNull();
        });
    }));
});
