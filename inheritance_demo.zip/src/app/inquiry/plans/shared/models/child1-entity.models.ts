import { IPartsListChoice } from '../../../../framework/models/form-controls.models';
import { IEntity } from '../../../../parts-common/models/postings.models';

export interface IChild1Entity extends IEntity {
    asOfDate: Date;
    accountCode: string;
    name1: string;
    name2: string;
    name3: string;
    addressLine1: string;
    addressLine2: string;
    addressLine3: string;
    city: string;
    zip: string;
    state: string;
    country: string;
    product: string;
    topHeavyCode: string;
    planType: string;
    planStatus: string;
    industryCode: string;
    inceptionDate: Date;
    addedDate: Date;
    removedDate: Date;
    lastAmendmentDate: Date;
    repaperedDate: Date;
    trustCustodianRelation: number;
    trustID: string;
    supressSSN: boolean;
    nonERISAPlan: boolean;
    overridePlanInfo: boolean;
    planStatusCodeList: Array<IPartsListChoice>;
    topHeavyCodeList: Array<IPartsListChoice>;
    ProductCodeList: Array<IPartsListChoice>;
    PlanRelationshipCodeList: Array<IPartsListChoice>;
    industryCodeList: Array<IPartsListChoice>;
    stateCodeList: Array<IPartsListChoice>;
}
