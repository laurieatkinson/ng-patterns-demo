import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { PostingEntityDataService } from '../../../../parts-common/services/posting-entity-data.service';
import { IAccount } from '../models/account.models';
import { UtilitiesService } from '../../../../framework/services/utilities.service';

@Injectable()
export class AccountDataService extends PostingEntityDataService {

    private _currentAccount: IAccount;
    private accountChangedSource = new Subject<void>();
    accountChanged = this.accountChangedSource.asObservable();

    get currentAccount() {
        return this._currentAccount;
    }

    userSelectedAnotherAccount() {
        return this.currentAccount.accountCode !== this.userSessionService.accountCode;
    }

    userUpdatedAccountName(name1: string, name2: string, name3: string) {
        this.currentAccount.name1 = name1;
        this.currentAccount.name2 = name2;
        this.currentAccount.name3 = name3;
    }

    getAccount(): Promise<IAccount> {
        const endpoint = this.endpoint();
        return this.get<IAccount>(endpoint).then((account: IAccount) => {
            this._currentAccount = account;
            this.accountChangedSource.next();
            return account;
        });
    }

    endpoint() {
        return this.constructEndpoint('account');
    }
}
