import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve } from '@angular/router';
import { UserSessionService } from '../../../../parts-common/services/user-session.service';
import { PartsPostingResolver } from '../../../../parts-common/services/parts-posting-resolver.service';
import { IPartsListChoice } from '../../../../framework/models/form-controls.models';

@Injectable()
export class PlanPostingResolver extends PartsPostingResolver {

    resolve(route: ActivatedRouteSnapshot) {
        const accountCode = route.params['code'];
        this.userSessionService.accountCode = accountCode;
        return super.resolve(route);
    }

    protected mapListToPickList(list: Array<{ ruleCode?: string, fundCode?: string, longName: string }>) {
        const result: Array<{ ruleCode: string, label: string }> = [];
        if (list) {
            list.forEach(item => {
                if (item.fundCode) {
                    result.push({ ruleCode: item.fundCode, label: item.longName });
                } else if (item.ruleCode) {
                    result.push({ ruleCode: item.ruleCode, label: item.longName });
                }
            });
        }
        return result;
    }

    protected mapListToChoiceList(
        list: Array<{ longName: string,
                      ruleCode?: string,
                      fundCode?: string,
                      code?: string }>) {
        const result: Array<IPartsListChoice> = [];
        if (list) {
            list.forEach(item => {
                if (item.fundCode) {
                    result.push({ value: item.fundCode, label: item.longName });
                } else if (item.ruleCode) {
                    result.push({ value: item.ruleCode, label: item.longName });
                } else if (item.code) {
                    result.push({ value: item.code, label: item.longName });
                }
            });
        }
        return result;
    }

    protected pushMoreItemsToChoiceList(
        list: Array<IPartsListChoice>,
        moreItems: Array<{ longName: string,
                      ruleCode?: string,
                      fundCode?: string,
                      code?: string }>) {
        if (!list) {
            list = [];
        }
        if (moreItems) {
            moreItems.forEach(item => {
                if (item.fundCode) {
                    list.push({ value: item.fundCode, label: item.longName });
                } else if (item.ruleCode) {
                    list.push({ value: item.ruleCode, label: item.longName });
                } else if (item.code) {
                    list.push({ value: item.code, label: item.longName });
                }
            });
        }
    }

    // Shortname should not be used as a key. It can be modified by the user
    // protected mapListToChoiceListUsingShortNameKey(
    //     list: Array<{ longName: string, shortName: string }>) {
    //     const result: Array<IPartsListChoice> = [];
    //     if (list) {
    //         list.forEach(item => {
    //             result.push({ value: item.shortName, label: item.longName });
    //         });
    //     }
    //     return result;
    // }

    // Remove the target list (right hand side) items from the source list (left hand side)
    protected removeItemsAlreadyExcluded(sourceList: Array<{ ruleCode: string, label: string }> = [],
        targetList: Array<{ ruleCode: string, label: string }>) {
        const pickList: Array<{ ruleCode: string, label: string }> = [];
        sourceList.forEach(sourceItem => {
            if (targetList.findIndex(targetItem => {
                return sourceItem.ruleCode === targetItem.ruleCode;
            }) === -1) {
                pickList.push(sourceItem);
            }
        });
        sourceList = pickList;
        return sourceList;
    }
}
